// Only the local Python launcher supplies OS telemetry. Never probes another host.
const $=id=>document.getElementById(id);
const valid=n=>typeof n==='number'&&Number.isFinite(n);
const fmt=(n,unit='')=>valid(n)?n.toLocaleString(undefined,{maximumFractionDigits:1})+unit:'Unavailable';
const gib=n=>valid(n)?fmt(n/1073741824,' GiB'):'Unavailable';
let latest=null,recording=null,timer=null,closed=false;
export const hardware={
 report(data){$('hardwareResult').hidden=false;const samples=data?.samples||[];const cpu=samples.map(s=>s.cpuPercent).filter(valid),ram=samples.map(s=>s.memory?.usedBytes).filter(valid);$('hardwareReport').textContent=samples.length? samples.length+' local snapshots · Average whole-PC CPU '+fmt(cpu.length?cpu.reduce((a,b)=>a+b,0)/cpu.length:null,'%')+' · Peak RAM use '+gib(ram.length?Math.max(...ram):null)+'. Sampled peaks can miss short spikes.':'No local hardware samples for this run. Use the Windows or Linux launcher to include OS readings.';const peaks=new Map();for(const s of samples)for(const x of s.sensors||[]){const key=x.source+' · '+x.name+' ('+x.unit+')';if(valid(x.value))peaks.set(key,Math.max(peaks.get(key)??-Infinity,x.value));}for(const s of samples)for(const g of s.gpus||[])for(const [field,label,unit] of [['utilizationPercent','GPU use','%'],['temperatureC','Temperature','°C'],['powerW','Power','W'],['usedVramBytes','VRAM used','bytes']]){const key=g.name+' · '+label+' ('+unit+')';if(valid(g[field]))peaks.set(key,Math.max(peaks.get(key)??-Infinity,g[field]));}rows('hardwarePeaks',[...peaks].map(([key,val])=>[key,'Sampled peak '+fmt(val)]));},
 startRecording(){recording={startedMs:Date.now(),samples:[],lastTimestamp:null};},
 finishRecording(){if(!recording)return null;const r=recording;recording=null;return{inventory:latest?.inventory||null,samples:r.samples,startedMs:r.startedMs,endedMs:Date.now(),source:'Local OS/driver collector',note:'Whole-system telemetry, including other applications. Sensors have different collection times; sample.collectionMs records collection latency. Missing values are unavailable, not zero. Collector activity adds some benchmark overhead.'};}
};
function rows(id,entries){const box=$(id);if(!box)return;box.replaceChildren();for(const[label,value]of entries){const dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=label;dd.textContent=value;box.append(dt,dd);}}
function render(data){
 const info=data.inventory,s=data.sample;latest=data;
 if(info){rows('hardwareInventory',[
 ['CPU',info.cpuModels.join(' / ')||'Unavailable'],['Cores / logical processors',(info.physicalCores??'Unknown')+' / '+(info.logicalProcessors??'Unknown')],['Operating system',info.os+' · '+info.architecture],
 ['Installed GPUs',info.gpus.map(g=>g.name+(g.driver?' · driver '+g.driver:'')).join(' / ')||s?.gpus?.map(g=>g.name).join(' / ')||'Unavailable'],
 ['RAM available to OS',gib(s?.memory?.totalBytes)],['Memory modules',info.memoryModules?.length?info.memoryModules.map(m=>gib(m.capacityBytes)+(valid(m.configuredSpeedReported)?' · configured speed '+m.configuredSpeedReported+' (CIM)':'')).join(' / '):'Not exposed without additional platform access'],
 ['Storage devices',info.disks.map(d=>(d.model||'Disk')+' · '+gib(d.sizeBytes)).join(' / ')||'Unavailable']]);}
 if(!s){$('hardwareStatus').textContent=data.error||'Detecting installed hardware…';return;}
 const age=Math.max(0,(Date.now()-s.timestampMs)/1000),stale=age>15;
 $('hardwareStatus').textContent=data.error||(stale?'Readings are stale · ':'Live local readings · ')+age.toFixed(0)+'s old · whole PC, including other apps';
 $('nativeCpu').textContent=stale?'Stale':fmt(s.cpuPercent,'%');$('nativeRam').textContent=stale?'Stale':gib(s.memory?.usedBytes)+' / '+gib(s.memory?.totalBytes);
 $('nativeGpu').textContent=stale?'Stale':s.gpus.length?s.gpus.map(g=>g.name+': '+fmt(g.utilizationPercent,'%')).join(' / '):'Unavailable; see sensor list';
 $('nativeClock').textContent=stale?'Stale':fmt(s.cpuFrequencyMHz,' MHz');
 const entries=[];
 for(const g of s.gpus){entries.push([g.name+' · driver readings','GPU '+fmt(g.utilizationPercent,'%')+' · VRAM '+gib(g.usedVramBytes)+' / '+gib(g.totalVramBytes)+' · '+fmt(g.temperatureC,' °C')+' · '+fmt(g.powerW,' W')+' · '+g.source]);}
 for(const sensor of s.sensors)entries.push([sensor.name,fmt(sensor.value,' '+sensor.unit)+' · '+sensor.source]);
 rows('hardwareSensors',entries.length?entries:[['Sensors','Unavailable. On Windows, a running LibreHardwareMonitor with accessible WMI can provide additional readings. Linux depends on kernel/driver hwmon support.']]);
 if(recording&&!stale&&s.timestampMs>=recording.startedMs&&s.timestampMs!==recording.lastTimestamp){recording.samples.push(s);recording.lastTimestamp=s.timestampMs;if(recording.samples.length>180)recording.samples.shift();}
}
async function poll(){if(closed)return;try{const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),3000);let response;try{response=await fetch('/api/hardware',{cache:'no-store',signal:controller.signal,credentials:'same-origin'});}finally{clearTimeout(timeout);}if(!response.ok)throw Error('Local collector unavailable');const data=await response.json();if(data.schema!==1)throw Error('Unsupported collector');render(data);}catch{$('hardwareStatus').textContent='Local monitor disconnected. Keep the launcher window open, then reload if needed.';for(const id of ['nativeCpu','nativeRam','nativeGpu','nativeClock'])$(id).textContent='Unavailable';}finally{if(!closed)timer=setTimeout(poll,2000);}}
export function initHardware(){if(typeof location==='undefined'||location.hostname!=='127.0.0.1'){$('hardwareStatus').textContent='Real hardware readings require the downloaded package: run start-windows.bat or sh start-linux.sh, then open the printed local URL. The hosted page measures browser performance only.';return;}poll();window.addEventListener('pagehide',()=>{closed=true;clearTimeout(timer);});}
