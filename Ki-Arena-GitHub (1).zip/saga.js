import{roster}from'./forms.js';
// All included forms, in a fixed repeatable order; no player input during a run.
export const sagaForms=Object.freeze(['goku','vegeta'].flatMap(hero=>roster[hero].forms.map((name,form)=>Object.freeze({hero,form,name}))));
export function sagaState(seconds,duration=180){
 const length=Number.isFinite(duration)&&duration>0?duration:180;
 const elapsed=Math.max(0,Math.min(length,seconds)),slot=length/sagaForms.length;
 const index=Math.min(sagaForms.length-1,Math.floor(elapsed/slot));
 const stage=sagaForms[index],local=Math.min(slot,Math.max(0,elapsed-index*slot));
 const foeForm=Math.min(roster.frieza.forms.length-1,Math.floor(elapsed/length*roster.frieza.forms.length));
 return{...stage,index,total:sagaForms.length,slot,local,foeForm,attack:stage.form%roster[stage.hero].attacks.length,entering:stage.form===0,powerUp:Math.max(0,1-local/Math.min(1,slot*.2)),choreography:local/slot*12};
}
export function sagaSchedule(duration){return sagaForms.map((stage,index)=>({...stage,startSeconds:index*duration/sagaForms.length,endSeconds:(index+1)*duration/sagaForms.length}));}
