export const median=a=>quantile(a,.5);
export function quantile(a,q){if(!a.length)return null;const s=[...a].sort((x,y)=>x-y),p=(s.length-1)*q,lo=Math.floor(p);return s[lo]+(s[Math.min(s.length-1,lo+1)]-s[lo])*(p-lo);}
export function summary(values){const m=median(values);return{median:m,min:Math.min(...values),max:Math.max(...values),spread:m?(Math.max(...values)-Math.min(...values))/m*100:0,samples:values};}
export function aggregateWorkers(items){const start=Math.min(...items.map(x=>x.start)),end=Math.max(...items.map(x=>x.end));return items.reduce((s,x)=>s+x.count,0)/((end-start)/1000);}
export function frameStats(intervals){const sorted=[...intervals].sort((a,b)=>b-a),slow=sorted.slice(0,Math.max(1,Math.ceil(sorted.length*.01)));return{fps:1000*intervals.length/intervals.reduce((a,b)=>a+b,0),p95:quantile(intervals,.95),low1:1000/(slow.reduce((a,b)=>a+b,0)/slow.length)};}
