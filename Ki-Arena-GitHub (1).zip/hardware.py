"""Read-only local OS telemetry. Standard library; missing sensors stay None.
No remote commands, network requests, administrator prompts, or serial numbers.
"""
import csv
import ctypes
import json
import math
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import threading
import time


def read(path):
    try:
        return Path(path).read_text(errors='replace').strip()
    except (OSError, ValueError):
        return ''


def number(value, scale=1):
    try:
        result = float(value) * scale
        return result if math.isfinite(result) else None
    except (TypeError, ValueError):
        return None


def command(args, timeout=4):
    try:
        result = subprocess.run(args, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=timeout,
                                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0) if os.name == 'nt' else 0)
        return result.stdout.strip() if result.returncode == 0 else ''
    except (OSError, subprocess.SubprocessError):
        return ''


def powershell(script, timeout=8):
    exe = shutil.which('powershell.exe') or shutil.which('pwsh')
    if not exe:
        return None
    output = command([exe, '-NoLogo', '-NoProfile', '-NonInteractive', '-Command',
                      "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8;$ErrorActionPreference='SilentlyContinue';" + script], timeout)
    try:
        return json.loads(output.lstrip('\ufeff'))
    except (ValueError, TypeError):
        return None


def items(value):
    return value if isinstance(value, list) else [value] if isinstance(value, dict) else []


def inventory():
    info = {'os': platform.system() + ' ' + platform.release(), 'architecture': platform.machine(),
            'logicalProcessors': os.cpu_count(), 'physicalCores': None, 'cpuModels': [], 'gpus': [], 'disks': [],
            'memoryModules': [], 'source': 'Operating system', 'virtualizationNote': 'A VM or container may expose virtual devices or host counters.'}
    if os.name == 'nt':
        raw = powershell("@{cpu=@(Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors);gpu=@(Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion);disks=@(Get-CimInstance Win32_DiskDrive | Select-Object Model,Size,InterfaceType);ram=@(Get-CimInstance Win32_PhysicalMemory | Select-Object Capacity,ConfiguredClockSpeed)} | ConvertTo-Json -Depth 5 -Compress", 20) or {}
        cpus = items(raw.get('cpu'))
        info['cpuModels'] = [c.get('Name', '').strip() for c in cpus if c.get('Name')]
        cores = [number(c.get('NumberOfCores')) for c in cpus]
        info['physicalCores'] = int(sum(cores)) if cores and all(c is not None for c in cores) else None
        info['gpus'] = [{'name': g.get('Name'), 'driver': g.get('DriverVersion'), 'source': 'Windows CIM'} for g in items(raw.get('gpu'))]
        info['disks'] = [{'model': d.get('Model'), 'sizeBytes': number(d.get('Size')), 'interface': d.get('InterfaceType')} for d in items(raw.get('disks'))]
        info['memoryModules'] = [{'capacityBytes': number(m.get('Capacity')), 'configuredSpeedReported': number(m.get('ConfiguredClockSpeed'))} for m in items(raw.get('ram'))]
    elif platform.system() == 'Linux':
        cpu = read('/proc/cpuinfo'); models = re.findall(r'^model name\s*:\s*(.+)$', cpu, re.M)
        info['cpuModels'] = list(dict.fromkeys(models)) or [platform.processor() or platform.machine()]
        cores = set()
        for block in cpu.split('\n\n'):
            fields = dict(re.findall(r'^([^:\n]+)\s*:\s*(.*)$', block, re.M)); fields = {k.strip(): v.strip() for k, v in fields.items()}
            if 'physical id' in fields and 'core id' in fields:
                cores.add((fields['physical id'], fields['core id']))
        info['physicalCores'] = len(cores) or None
        pci = command(['lspci', '-D'])
        for line in pci.splitlines():
            if re.search(r'VGA compatible controller|3D controller|Display controller', line):
                info['gpus'].append({'name': line.split(': ', 1)[-1], 'source': 'lspci'})
        if not info['gpus']:
            for card in Path('/sys/class/drm').glob('card[0-9]*'):
                if not re.fullmatch(r'card\d+', card.name): continue
                vendor, device = read(card/'device/vendor'), read(card/'device/device')
                if vendor: info['gpus'].append({'name': card.name + ' · PCI ' + vendor + ':' + device, 'source': 'Linux sysfs (model name unavailable)'})
        try:
            disks = json.loads(command(['lsblk', '-b', '-J', '-d', '-o', 'NAME,MODEL,SIZE,TRAN,TYPE']) or '{}')
            info['disks'] = [{'model': d.get('model') or d['name'], 'sizeBytes': number(d.get('size')), 'interface': d.get('tran')} for d in disks.get('blockdevices', []) if d.get('type') == 'disk']
        except (ValueError, KeyError): pass
    return info


def cpu_times():
    if os.name == 'nt':
        # GetSystemTimes is group-scoped on >64 processors: do not label it whole-PC.
        if (os.cpu_count() or 1) > 64: return None
        from ctypes import wintypes
        idle, kernel, user = wintypes.FILETIME(), wintypes.FILETIME(), wintypes.FILETIME()
        if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)): return None
        val = lambda f: (f.dwHighDateTime << 32) | f.dwLowDateTime
        return val(kernel) + val(user), val(idle)
    if platform.system() == 'Linux':
        first = read('/proc/stat').splitlines()
        if not first: return None
        vals = [int(v) for v in first[0].split()[1:9]] # exclude guest, already included in user/nice
        return sum(vals), vals[3] + (vals[4] if len(vals) > 4 else 0)
    return None


def cpu_percent(previous, current):
    if previous is None or current is None: return None
    total, idle = current[0] - previous[0], current[1] - previous[1]
    return max(0, min(100, 100 * (total - idle) / total)) if total > 0 and idle >= 0 else None


def memory():
    if os.name == 'nt':
        class Status(ctypes.Structure):
            _fields_ = [('length', ctypes.c_uint32), ('load', ctypes.c_uint32)] + [(name, ctypes.c_uint64) for name in ['total', 'available', 'pageTotal', 'pageAvailable', 'virtualTotal', 'virtualAvailable', 'extended']]
        s = Status(); s.length = ctypes.sizeof(s)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s)):
            return {'totalBytes': s.total, 'availableBytes': s.available, 'usedBytes': s.total-s.available}
    elif platform.system() == 'Linux':
        fields = {k: int(v)*1024 for k, v in re.findall(r'^(\w+):\s+(\d+) kB', read('/proc/meminfo'), re.M)}
        total, available = fields.get('MemTotal'), fields.get('MemAvailable')
        return {'totalBytes': total, 'availableBytes': available, 'usedBytes': total-available if total is not None and available is not None else None}
    return {'totalBytes': None, 'availableBytes': None, 'usedBytes': None}


def linux_sensors():
    sensors = []
    for chip in sorted(Path('/sys/class/hwmon').glob('hwmon*')):
        name = read(chip/'name') or chip.name
        for prefix, kind, unit, scale in [('temp', 'temperature', '°C', .001), ('power', 'power', 'W', .000001), ('fan', 'fan', 'RPM', 1)]:
            paths = list(chip.glob(prefix+'*_input'))
            if prefix == 'power': paths += list(chip.glob('power*_average'))
            for path in paths:
                stem = path.name.rsplit('_', 1)[0]
                if read(chip/(stem+'_fault')) == '1': continue
                value = number(read(path), scale)
                if value is not None:
                    sensors.append({'name': name+' · '+(read(chip/(stem+'_label')) or path.name), 'kind': kind, 'value': value, 'unit': unit, 'source': 'Linux hwmon'})
    return sensors


def nvidia_gpus():
    exe = shutil.which('nvidia-smi')
    if not exe and os.name == 'nt':
        candidate = Path(os.environ.get('ProgramFiles', 'C:/Program Files'))/'NVIDIA Corporation/NVSMI/nvidia-smi.exe'
        if candidate.is_file(): exe = str(candidate)
    if not exe: return []
    output = command([exe, '--query-gpu=index,name,utilization.gpu,memory.total,memory.used,temperature.gpu,power.draw', '--format=csv,noheader,nounits'], 3)
    rows = []
    for row in csv.reader(output.splitlines()):
        if len(row) != 7: continue
        idx, name, use, total, used, temp, power = [x.strip() for x in row]
        rows.append({'name': name, 'index': idx, 'utilizationPercent': number(use), 'totalVramBytes': number(total, 1024**2), 'usedVramBytes': number(used, 1024**2), 'temperatureC': number(temp), 'powerW': number(power), 'source': 'NVIDIA driver (nvidia-smi)'})
    return rows


def linux_gpus():
    rows = []
    for card in sorted(Path('/sys/class/drm').glob('card[0-9]*')):
        if not re.fullmatch(r'card\d+', card.name): continue
        device = card/'device'; use = number(read(device/'gpu_busy_percent'))
        total = number(read(device/'mem_info_vram_total')); used = number(read(device/'mem_info_vram_used'))
        if any(v is not None for v in (use, total, used)):
            rows.append({'name': card.name+' · '+read(device/'vendor')+':'+read(device/'device'), 'utilizationPercent': use, 'totalVramBytes': total, 'usedVramBytes': used, 'temperatureC': None, 'powerW': None, 'source': 'Linux DRM driver; temperatures listed under sensors'})
    return rows


def windows_sensors():
    # Optional: reads an already running LibreHardwareMonitor WMI provider.
    data = powershell("@(Get-CimInstance -Namespace root/LibreHardwareMonitor -ClassName Sensor | Where-Object {$_.SensorType -in @('Temperature','Power','Load','Data','SmallData','Clock','Fan')} | Select-Object Name,Parent,SensorType,Value) | ConvertTo-Json -Depth 3 -Compress", 5)
    units = {'Temperature': ('temperature', '°C'), 'Power': ('power', 'W'), 'Load': ('load', '%'), 'Data': ('data', 'GB'), 'SmallData': ('data', 'MB'), 'Clock': ('clock', 'MHz'), 'Fan': ('fan', 'RPM')}
    result = []
    for s in items(data):
        kind = s.get('SensorType'); val = number(s.get('Value'))
        if kind in units and val is not None:
            result.append({'name': str(s.get('Parent', ''))+' · '+str(s.get('Name', '')), 'kind': units[kind][0], 'unit': units[kind][1], 'value': val, 'source': 'LibreHardwareMonitor WMI'})
    return result


class HardwareMonitor:
    def __init__(self):
        self.lock = threading.Lock(); self.stop_event = threading.Event()
        self.state = {'schema': 1, 'ready': False, 'inventory': None, 'sample': None, 'error': None}
        self.thread = threading.Thread(target=self.run, daemon=True, name='ki-hardware')

    def start(self): self.thread.start()
    def close(self): self.stop_event.set()
    def snapshot(self):
        with self.lock: return json.loads(json.dumps(self.state))

    def run(self):
        try:
            info = inventory()
            with self.lock: self.state.update(inventory=info, ready=True)
            previous = cpu_times()
            self.stop_event.wait(1)
            while not self.stop_event.is_set():
                started = time.monotonic(); current = cpu_times()
                # Timestamp CPU/memory readings independently of slower driver calls.
                sample = {'timestampMs': int(time.time()*1000), 'cpuPercent': cpu_percent(previous, current), 'memory': memory(), 'gpus': [], 'sensors': []}
                previous = current
                sample['gpus'] = nvidia_gpus()
                if platform.system() == 'Linux':
                    sample['gpus'] += linux_gpus(); sample['sensors'] = linux_sensors()
                    clocks = [number(read(p), .001) for p in Path('/sys/devices/system/cpu').glob('cpu[0-9]*/cpufreq/scaling_cur_freq')]
                    clocks = [x for x in clocks if x is not None]
                    sample['cpuFrequencyMHz'] = sum(clocks)/len(clocks) if clocks else None
                elif os.name == 'nt': sample['sensors'] = windows_sensors()
                sample['collectionMs'] = round((time.monotonic()-started)*1000)
                with self.lock: self.state.update(sample=sample, error=None)
                self.stop_event.wait(max(.5, 2-(time.monotonic()-started)))
        except Exception as exc:
            with self.lock: self.state['error'] = 'Hardware collection unavailable: '+type(exc).__name__
