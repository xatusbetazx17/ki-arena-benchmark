# Ki Arena 3.2 — Native hardware monitor for Windows and Linux

Download and extract the entire ZIP, then run **start-windows.bat** on Windows or **sh start-linux.sh** on Linux. Python 3 is required; no pip packages are needed. Keep the console open and use the exact `http://127.0.0.1:PORT/` URL printed by the launcher. The hosted website cannot read OS hardware; the local version adds that access.

## What is measured

| Reading | Windows | Linux |
| --- | --- | --- |
| CPU model, physical cores, logical processors | Windows CIM | /proc/cpuinfo and OS |
| GPU model / installed adapters | Windows CIM | lspci, or PCI identifiers in sysfs |
| Live whole-system CPU use | GetSystemTimes (up to 64 logical processors) | /proc/stat deltas |
| RAM usable by OS / used / available | GlobalMemoryStatusEx | /proc/meminfo |
| RAM module capacities and configured speed | CIM when available | Not collected without additional platform access |
| Disk model / capacity | Windows CIM | lsblk, if available |
| NVIDIA utilization, VRAM, temperature, power | nvidia-smi with compatible NVIDIA driver | Same |
| AMD GPU utilization and VRAM | Optional LibreHardwareMonitor sensor data | DRM sysfs when exposed |
| CPU / board temperatures, power, fans and other sensors | Optional running LibreHardwareMonitor WMI provider | Kernel hwmon files when readable |
| CPU frequency | Optional LibreHardwareMonitor sensor list | Average available cpufreq readings |

Unknown, inaccessible and unsupported values stay unavailable. RAM totals are OS-usable physical memory; reserved hardware memory may differ from the sum of installed DIMMs. Disk capacity is inventory, not a disk-speed test. Sensor power is for the named component, not automatically whole-PC wall power. GPU adapter inventory and the browser's active renderer can differ on multi-GPU systems. Linux hardware names are best with your distribution's `pciutils` package installed; no package is automatically installed. Virtual machines and containers may expose virtual devices, restricted inventory or host-level counters. Windows CPU usage is left unavailable above 64 logical processors to avoid mislabeling a processor-group counter.

For additional Windows sensors, use the official LibreHardwareMonitor project: https://github.com/LibreHardwareMonitor/LibreHardwareMonitor . Run it with its WMI provider accessible while the launcher runs. The game does not bundle drivers, install it or request administrator access. Sensor support and permissions vary. NVIDIA data requires `nvidia-smi` installed with the driver and reachable on PATH or the standard NVSMI directory.

## During and after a battle

The arena shows live CPU use, RAM use, GPU driver usage and CPU frequency. Expand **Installed hardware and live sensors** for device names, temperatures, VRAM, power and fan readings. The final report adds average sampled CPU use, peak sampled RAM use, sensor peaks and raw snapshots in exported JSON. Readings cover the full run, including warm-up, and include other programs running on the PC. The collector targets roughly two-second updates; slow driver/provider calls can take longer. Each snapshot includes timestamp and collection latency. Readings older than 15 seconds are marked stale. Sampled peaks can miss brief spikes.

CPU simulation and uncapped WebGL measurements remain real browser workloads. Adding OS monitoring does not turn their scores into a universal hardware rating or native-game performance prediction. Monitoring adds overhead; compare the same app version, drivers, browser, workload and monitoring setup.

The read-only collector serves only loopback. It rejects incorrect Host headers and foreign browser origins; it sends no hardware data to the internet. No serial numbers, user names, process names or network addresses are collected. Exported JSON contains device models and sensor data. Closing the console ends the collector; Stop test stops the benchmark while monitoring continues until the launcher closes.

Validation: real Linux CPU/RAM collection, local API access checks, frontend telemetry recording and report tests pass. Windows provider parsing is tested with fixtures; actual Windows execution, GPU sensors and real GPU visuals remain unverified in this environment.

Sources: https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getsystemtimes ; https://docs.kernel.org/hwmon/sysfs-interface.html ; https://docs.nvidia.com/deploy/nvidia-smi/

# Ki Arena 3.1 — Automatic Goku → Vegeta battle

The default battle now visits every included Goku form (14), then Vegeta enters and visits every included Vegeta form (11), ending in Ultra Ego. Frieza transforms through all eight included forms and reaches Black. Attacks rotate automatically, with an entry animation and a visible power-up at each form change.

Choose **Automatic · Goku → Vegeta** and start the benchmark. The default is 180 seconds: 7.2 seconds per hero form. The 60- and 120-second runs fit the same 25 stages into 2.4 and 4.8 seconds per form. The final form holds through the end; the sequence never loops back early. This showcases the included forms (including marked GT branches), not a canonical story order. JSON results include the complete scheduled transformation timeline.

Manual forms and the older one-fighter 12-second transformation tour remain available. All benchmark settings are frozen while a test runs. Version 3.1 auto-sequence results should be compared with matching 3.1 settings and duration.

# Version 3 additions

- Uncapped off-screen WebGL2 scene throughput, measured by completed GPU-fenced batches, independent of the display refresh loop. Display FPS is reported separately.
- 14 Goku forms, 11 Vegeta forms (including Ultra Ego), and 8 Frieza forms (including Black). Major Z/Super forms with explicitly marked GT branches; a curated selection, not every franchise transformation or technique.
- Select beam, orb, rush, teleport, disc, volley and explosion effects through signature attacks. Frieza cycles his attack catalog. Optional single-fighter transformations every 12 seconds; 1×/2×/4× aura density.
- Ultra 2560×1440/250,000 sparks and Extreme 3840×2160/500,000 sparks; up to 64 browser-exposed CPU workers. Default caps selection at 16 workers. No automatic quality changes mid-run.

Uncapped result = GPU-completed scenes / full measured wall time. Eight scenes per batch; asynchronous fence polling confirms completion. Boundary-crossing batches are excluded conservatively. JavaScript, scheduling, polling, preview and CPU contention are included. This is completed-scene throughput, not native-game FPS or a GPU-only score. GPU timers, when available, time individual draws rather than the full wall-time pipeline. The separate component graphics test remains display paced.

Compare only version 3 with identical forms, attack, tour, density, duration, preset, browser and worker count. The JSON includes the selections, completed scene count, batch trace, CPU results and display frame intervals. Transformation visuals do not imply scientifically measurable fictional power.

Validation uses real CPU workers and simulated graphics for orchestration. Real GPU performance, visual browser rendering and Windows launch execution have not been verified in this environment. Art is stylized generated 2D sprites; some aura edges are cropped.

## Run on Windows or Linux

Extract the complete ZIP. Install Python 3 and use a browser with WebGL 2 hardware acceleration.

- Windows: double-click `start-windows.bat`.
- Linux: run `sh start-linux.sh`.

Keep the launcher console open. It starts a Python standard-library server on 127.0.0.1 using a free port, then opens your browser. No package installation is needed. If it cannot open the browser, paste the printed local URL. Stop the server with Ctrl+C. This is source with launchers, not a compiled EXE or Linux installer. Hosted use does not require Python.

## Modes and measurements

Combined battle runs CPU workers and uncapped rendering simultaneously for 60, 120 or 180 seconds after warm-up. Stop/Escape cancels; changing tabs also cancels to prevent background-throttled scores. Partial results are discarded. Individual components measure single-worker CPU, multi-worker CPU, memory copying and display-paced WebGL. Free battle is a separate interactive drone-defense game without scores.

The CPU kernel updates 2,048 seeded particles. Throughput counts complete particle updates over the observed shared worker interval, including scheduling pauses. This is not FLOPS. Workers yield between roughly 24 ms chunks for cancellation. Memory tests copy between two 32 MiB buffers; logical bytes copied are reported, not rated RAM bandwidth. Component stages warm for 600 ms and take three 1.5-second samples. Component graphics warms for one second, then measures three three-second samples.

Display FPS is the reciprocal of mean frame interval. The 1% low uses the mean of the slowest 1% of intervals. P95 is the 95th-percentile frame interval. Early/late display FPS changes do not diagnose thermal throttling. GPU draw timers are optional; invalid disjoint samples are discarded.

Standard: 1280×720, 40,000 sparks. Heavy: 1920×1080, 100,000 sparks. Higher presets are listed above. All settings are fixed during measurement except the explicitly selected deterministic transformation tour. Form/attack combos are sandbox choices rather than canon restrictions.

Hosted browsers alone cannot reliably provide temperatures, watts, exact CPU model, CPU utilization percentage, VRAM capacity, or native hardware stability. Local launcher sensor support is described above. Results are local and not uploaded. Hardware labels may be masked. A real test creates sustained load; start with Standard and stop if needed.

## GitHub

Upload the extracted files to a repository. For GitHub Pages, publish the branch root; `index.html` and assets are at the root of this ZIP. No build step, CDN, credentials or backend is required. The Sites development checkout uses a `dist/` folder, while the portable ZIP is flattened.

Run `python3 tests/hardware_test.py`, `node tests/hardware-ui.mjs`, `node tests/saga.mjs`, `node tests/uncapped.mjs`, `node tests/benchmark.mjs`, and `node tests/benchmark.mjs --battle` (Node 22+). The final test takes about 64 seconds. These validate math, forms, fence orchestration, real CPU/memory work, cancellation and worker cleanup with a simulated GPU. They do not validate actual graphics drivers or Windows.

Unofficial fan project. Included generated artwork depicts Dragon Ball characters; it is not an official product. Do not claim ownership of the franchise. Techniques are stylized effects rather than physically accurate energy or damage calculations.

Technical reference: https://registry.khronos.org/webgl/specs/latest/2.0/
