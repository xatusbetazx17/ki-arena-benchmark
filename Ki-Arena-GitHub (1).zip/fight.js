import{sagaState}from'./saga.js';
import{roster,addAttack}from'./forms.js';
// Deterministic animation timeline: identical action at the same elapsed time.
export function fightFrame(seconds,selection={hero:"goku",form:0,foeForm:3,attack:0,intensity:1,tour:false}){
 const saga=selection.sequence==='saga'?sagaState(seconds,selection.duration):null;
 if(saga)selection={...selection,hero:saga.hero,form:saga.form,foeForm:saga.foeForm,attack:saga.attack,tour:false};
 const t=saga?saga.choreography:((seconds%12)+12)%12,cycle=saga?saga.index+1:Math.floor(seconds/12)+1;
 let gx=.23,fx=.77,gPose=0,fPose=0,attack='Opening stance',beam=0,charge=0,enemyBeam=0;
 if(t>=1.5&&t<4){const u=(t-1.5)/2.5;gx=.23+.39*Math.sin(Math.PI*Math.min(1,u*1.6));gPose=Math.floor(t*9)%2;fPose=3;fx+=Math.sin(t*48)*.008;attack='Close combat';}
 else if(t>=4&&t<5.5){fPose=2;enemyBeam=Math.sin((t-4)/1.5*Math.PI);gx+=Math.sin(t*35)*.006;attack='Frieza counters';}
 else if(t>=5.5&&t<7.5){gPose=3;charge=(t-5.5)/2;attack='Goku charges his ki';}
 else if(t>=7.5&&t<10.5){gPose=2;fPose=3;beam=Math.min(1,(t-7.5)*5)*Math.min(1,(10.5-t)*3);fx+=Math.sin(t*45)*.012;attack='Kamehameha';}
 else if(t>=10.5){gPose=3;charge=(12-t)/1.5;attack='Energy shockwave';}
 const points=[];const add=(x,y,size,type)=>points.push(x,y,size,type);
 if(beam){for(let i=0;i<120;i++){const x=gx+.08+i/119*(fx-gx-.1);const wave=Math.sin(i*.8+seconds*24)*.008*beam;add(x,.53+wave,12+beam*20,2);}for(let i=0;i<100;i++){const a=i*2.399+seconds*4,r=((i%19)/19)*.11*beam;add(fx+Math.cos(a)*r,.55+Math.sin(a)*r,8+beam*20,2);}}
 if(enemyBeam){for(let i=0;i<60;i++)add(gx+.05+i/59*(fx-gx-.11),.54+Math.sin(i+seconds*20)*.003,7+enemyBeam*7,3);}
 if(charge){for(let i=0;i<90;i++){const a=i*2.4+seconds*3,r=(.04+(i%13)*.003)*charge;add(gx+Math.cos(a)*r,.58+Math.sin(a)*r*2.1,4+charge*15,4);}}
 const hero=roster[selection.hero]||roster.goku,form=selection.tour?Math.floor(seconds/12)%hero.forms.length:Number(selection.form),foeForm=selection.tour?Math.floor(seconds/12)%8:Number(selection.foeForm);
 if(t>=5.5&&t<7.5)attack=hero.name+' charges ki';
 const chosen=hero.attacks[Number(selection.attack)]||hero.attacks[0],enemy=roster.frieza.attacks[(saga?saga.index:Math.floor(seconds/12))%roster.frieza.attacks.length];
 if(t>=7.5&&t<10.5){points.length=0;attack=chosen[0];if(chosen[1]==='teleport'){gx=.6;addAttack(points,'beam',gx,fx,seconds,2,selection.intensity);}else{if(chosen[1]==='rush')gx=.67;addAttack(points,chosen[1],gx,fx,seconds,selection.hero==='vegeta'?5:2,selection.intensity);}}
 if(t>=4&&t<5.5){points.length=0;attack=enemy[0];addAttack(points,enemy[1],fx,gx,seconds,5,selection.intensity);}
 for(let i=0;i<(form+1)*12*selection.intensity;i++){const a=i*2.4+seconds*3;add(gx+Math.cos(a)*.07,.6+Math.sin(a)*.2,8,form===10&&selection.hero==='vegeta'?5:form>=9?2:3);}
 if(saga?.powerUp){
  attack=saga.entering?(saga.hero==='vegeta'?'Vegeta enters the fight!':'Goku enters the fight!'):'Transforming · '+hero.forms[form];
  if(saga.entering)gx=.23-.32*saga.powerUp;
  for(let i=0;i<180*selection.intensity;i++){const a=i*2.399,r=(1-saga.powerUp)*.22;add(gx+Math.cos(a)*r,.59+Math.sin(a)*r*1.4,8+saga.powerUp*18,selection.hero==='vegeta'?5:2);}
 }
 return{saga:saga?{index:saga.index,total:saga.total,hero:saga.hero}:null,gx,fx,gPose,fPose,attack,cycle,hero:selection.hero,form,foeForm,heroLabel:hero.name+' · '+hero.forms[form],foeLabel:'Frieza · '+roster.frieza.forms[foeForm],points:new Float32Array(points)};
}
export async function loadBattleImages(){
 const names=['goku','frieza','stage','goku-forms','vegeta-forms','frieza-forms'];
 const images=await Promise.all(names.map(name=>new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(Error('Could not load '+name+' artwork. Reload or check the assets folder.'));img.src=new URL('./assets/'+name+'.png',import.meta.url).href;})));
 return Object.fromEntries(names.map((n,i)=>[n,images[i]]));
}
