import assert from 'node:assert/strict';
import {sagaState,sagaSchedule,sagaForms} from '../saga.js';
import {fightFrame} from '../fight.js';
assert.equal(sagaForms.length,25);
for(const duration of [60,120,180]){
 const schedule=sagaSchedule(duration),forms=[];
 for(let i=0;i<25;i++){
  const time=(i+.5)*duration/25,frame=fightFrame(time,{sequence:'saga',duration,intensity:4});
  forms.push(`${frame.hero}:${frame.form}`);assert.equal(frame.saga.index,i);assert.equal(frame.saga.total,25);
  assert([...frame.points].every(Number.isFinite));assert(frame.points.length<=40000);
 }
 assert.equal(new Set(forms).size,25);assert.deepEqual(forms.slice(0,14),Array.from({length:14},(_,i)=>`goku:${i}`));assert.deepEqual(forms.slice(14),Array.from({length:11},(_,i)=>`vegeta:${i}`));
 const change=14*duration/25;assert.equal(sagaState(change-.00001,duration).hero,'goku');assert.equal(sagaState(change,duration).hero,'vegeta');
 assert.match(fightFrame(change,{sequence:'saga',duration,intensity:1}).attack,/Vegeta enters/);
 const end=fightFrame(duration,{sequence:'saga',duration,intensity:1});assert.equal(end.hero,'vegeta');assert.equal(end.form,10);assert.equal(end.foeForm,7);
 assert.equal(schedule[0].startSeconds,0);assert.equal(schedule.at(-1).endSeconds,duration);
 assert.equal(sagaState(duration+20,duration).index,24);assert.equal(sagaState(-1,duration).index,0);
 const frieza=new Set(Array.from({length:80},(_,i)=>sagaState((i+.5)*duration/80,duration).foeForm));assert.equal(frieza.size,8);
}
console.log('PASS: all 25 hero stages and 8 Frieza forms, Goku-to-Vegeta handoff, full duration coverage, entry effect, stable final form and finite effects.');
