import {sagaSchedule} from '../saga.js';
import {spriteBounds} from '../sprite-bounds.js';
import {roster} from '../forms.js';
import {UncappedPass} from '../uncapped.js';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {Worker as NodeWorker} from 'node:worker_threads';
import {fightFrame} from '../fight.js';
import {median,summary,aggregateWorkers,frameStats} from '../stats.js';
assert.equal(median([2,1,9]),2);assert.equal(median([1,3]),2);assert.equal(summary([90,100,110]).spread,20);
assert.ok(Math.abs(aggregateWorkers([{start:0,end:1000,count:100},{start:100,end:1100,count:120}])-200)<1e-9);
const f=frameStats(Array(100).fill(20));assert.equal(f.fps,50);assert.equal(f.low1,50);assert.equal(f.p95,20);
// Exercise real workload code and UI orchestration without a GPU/browser runtime.
const workerFile=new URL('../worker.js',import.meta.url),html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');
let alive=0;
class BrowserWorker{
 constructor(){this.w=new NodeWorker(`const {parentPort}=require('node:worker_threads');global.self={postMessage:d=>parentPort.postMessage(d)};require(${JSON.stringify(workerFile.pathname)});parentPort.on('message',d=>self.onmessage({data:d}));`,{eval:true});alive++;this.w.on('message',data=>this.onmessage?.({data}));this.w.on('error',e=>this.onerror?.(e));this.w.on('exit',()=>alive--);}
 postMessage(d){this.w.postMessage(d)}terminate(){return this.w.terminate()}
}
const battleMode=process.argv.includes('--battle');
let rafActive=true,renderCalls=0;
const fakeGl=new Proxy({}, {get:(o,k)=>{if(k==='checkFramebufferStatus')return()=>1;if(k==='clientWaitSync')return()=>2;if(k==='ALREADY_SIGNALED')return 2;if(k==='WAIT_FAILED')return 3;if(k==='getExtension')return()=>null;if(k==='getParameter')return()=> 'Test graphics context';if(k==='getShaderParameter'||k==='getProgramParameter')return()=>true;if(k==='drawArrays')return()=>{renderCalls++};if(typeof k==='string'&&k===k.toUpperCase())return 1;return()=>({});}});
const ctx2d=new Proxy({},{get:(_,key)=>()=>{}});
const makeNode=(tag='div')=>({tagName:tag.toUpperCase(),value:'',disabled:false,hidden:false,textContent:'',style:{},clientWidth:600,dataset:{},listeners:{},classList:{toggle(){},add(){},remove(){}},add(o){if(!this.value)this.value=String(o.value)},addEventListener(e,fn){this.listeners[e]=fn},setAttribute(){},replaceChildren(){},append(){},focus(){},getContext(type){return type==='webgl2'?(battleMode?fakeGl:null):ctx2d},getBoundingClientRect(){return{width:800,height:500,left:0,top:0}},click(){return this.listeners.click?.({target:this})}});
const nodes={};for(const match of html.matchAll(/<([a-z]+)[^>]*\bid="([^"]+)"[^>]*>/g))nodes[match[2]]=makeNode(match[1]);nodes.preset.value='standard';nodes.testMode.value=battleMode?'battle':'components';nodes.duration.value='60';nodes.hero.value='goku';nodes.intensity.value='1';nodes.tour.value='saga';
const weapons=['blast','beam','spirit'].map(name=>{const n=makeNode('button');n.dataset.weapon=name;return n});const docEvents={},winEvents={};
const document={getElementById:id=>{assert(nodes[id],'Missing element '+id);return nodes[id]},querySelectorAll:()=>weapons,createElement:makeNode,addEventListener:(e,fn)=>docEvents[e]=fn,hidden:false};
const globals={document,navigator:{hardwareConcurrency:2,userAgent:'Node integration test'},window:{addEventListener:(e,fn)=>winEvents[e]=fn},Option:function(text,value){this.value=value},ResizeObserver:class{observe(){}},requestAnimationFrame(fn){if(battleMode&&rafActive)setTimeout(()=>fn(performance.now()),16)},devicePixelRatio:1,Worker:BrowserWorker,performance,DOMException,AbortController,setTimeout,clearTimeout,setInterval,clearInterval,console,URL,Blob,median,summary,aggregateWorkers,frameStats};
const loadBattleImages=()=>battleMode?Promise.resolve({goku:{},frieza:{},stage:{}}):Promise.reject(Error('Art loading skipped in non-rendering test'));
globals.spriteBounds=spriteBounds;globals.hardware={startRecording(){},finishRecording(){return null},report(){}};globals.initHardware=()=>{};globals.sagaSchedule=sagaSchedule;globals.roster=roster;globals.UncappedPass=UncappedPass;globals.fightFrame=fightFrame;globals.loadBattleImages=loadBattleImages;
const src=fs.readFileSync(new URL('../app.js',import.meta.url),'utf8').replace(/^import[^\n]+\n/gm,'');vm.runInNewContext(src,globals);
if(battleMode){
 await new Promise(r=>setTimeout(r,50));
 const run=nodes.run.click();await run;
 assert.match(nodes.status.textContent,/Battle complete/);assert.equal(nodes.battleGrid.hidden,false);assert.ok(Number(nodes.battleCpu.textContent.replaceAll(',',''))>0);assert.ok(renderCalls>100);assert.equal(nodes.export.disabled,false);
 assert.match(nodes.heroName.textContent,/Vegeta/);assert.match(nodes.foeName.textContent,/Black Frieza/);const completed=nodes.battleCpu.textContent;const cancelled=nodes.run.click();setTimeout(()=>nodes.stop.click(),120);await cancelled;assert.equal(nodes.battleCpu.textContent,completed);assert.match(nodes.status.textContent,/stopped/);
 rafActive=false;await new Promise(r=>setTimeout(r,100));assert.equal(alive,0);
 console.log('PASS: full 60-second combined battle orchestration with real workers and simulated graphics calls; result report, cancellation, cleanup. Graphics visual output is not covered.');
}else{
const run=nodes.run.click();await run;assert.equal(nodes.singleResult.textContent==='—',false);assert.equal(nodes.gpuResult.textContent,'Unavailable');assert.equal(nodes.export.disabled,false);assert.match(nodes.status.textContent,/complete/);const completed=nodes.singleResult.textContent;
const cancelled=nodes.run.click();setTimeout(()=>nodes.stop.click(),200);await cancelled;assert.equal(nodes.singleResult.textContent,completed);assert.match(nodes.status.textContent,/stopped/);assert.equal(nodes.run.disabled,false);
const hidden=nodes.run.click();setTimeout(()=>{document.hidden=true;docEvents.visibilitychange()},200);await hidden;assert.match(nodes.status.textContent,/hidden/);
await new Promise(r=>setTimeout(r,100));assert.equal(alive,0);console.log('PASS: math, full CPU/memory run, WebGL fallback, cancellation, hidden-tab rejection, worker teardown.');

}
