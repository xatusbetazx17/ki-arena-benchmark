"""Native Linux smoke, Windows provider parsing, and loopback endpoint checks."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import json
import threading
import time
import urllib.request
import urllib.error
from unittest.mock import patch
import hardware
import launcher

assert hardware.cpu_percent((100, 50), (200, 70)) == 80
assert hardware.cpu_percent(None, (200, 70)) is None
assert hardware.cpu_percent((200, 70), (200, 70)) is None
assert hardware.number('N/A') is None
assert hardware.number('nan') is None
with patch.object(hardware.shutil, 'which', return_value='/driver/nvidia-smi'), patch.object(hardware, 'command', return_value='0, Test GPU, 35, 8192, 2048, 65, 120\n1, Second GPU, N/A, N/A, N/A, N/A, N/A'):
    gpu=hardware.nvidia_gpus();assert gpu[0]['totalVramBytes']==8192*1024**2;assert gpu[1]['powerW'] is None
with patch.object(hardware.os, 'name', 'nt'), patch.object(hardware, 'powershell', return_value={'cpu':[{'Name':'Fixture CPU','NumberOfCores':8}], 'gpu':[{'Name':'Fixture GPU','DriverVersion':'123'}], 'disks':[{'Model':'Fixture SSD','Size':1000}], 'ram':[{'Capacity':4096}]}):
    info=hardware.inventory();assert info['physicalCores']==8;assert info['gpus'][0]['name']=='Fixture GPU';assert info['memoryModules'][0]['capacityBytes']==4096
with patch.object(hardware, 'powershell', return_value=[{'Name':'CPU Package','Parent':'/cpu/0','SensorType':'Temperature','Value':67.5},{'Name':'Missing','SensorType':'Power','Value':None}]):
    sensors=hardware.windows_sensors();assert len(sensors)==1;assert sensors[0]['unit']=='°C'
server=launcher.make_server();thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();url='http://127.0.0.1:'+str(server.server_address[1])
try:
    deadline=time.monotonic()+25
    data=None
    while time.monotonic()<deadline:
        with urllib.request.urlopen(url+'/api/hardware',timeout=3) as r:
            data=json.load(r);assert r.headers['Cross-Origin-Resource-Policy']=='same-origin'
        if data.get('sample') and data['sample']['cpuPercent'] is not None:break
        time.sleep(.2)
    assert data['ready'],data
    assert data['inventory']['cpuModels']
    assert data['sample']['memory']['totalBytes']>0
    assert 0<=data['sample']['cpuPercent']<=100
    for headers in [{'Host':'evil.example'},{'Origin':'https://evil.example'},{'Sec-Fetch-Site':'cross-site'}]:
        try:urllib.request.urlopen(urllib.request.Request(url+'/api/hardware',headers=headers));raise AssertionError('Expected rejection')
        except urllib.error.HTTPError as e:assert e.code==403
    with urllib.request.urlopen(url+'/hardware.js') as r:assert r.status==200
    print('PASS: real Linux CPU/RAM and local endpoint; host/origin rejection; mocked Windows CIM/LHM and NVIDIA parsing. Windows execution and real GPU sensors not verified.')
finally:
    server.hardware.close();server.shutdown();server.server_close()
