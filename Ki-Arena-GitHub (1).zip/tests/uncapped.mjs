import assert from 'node:assert/strict';
import {UncappedPass} from '../uncapped.js';
import {roster} from '../forms.js';
import {fightFrame} from '../fight.js';
let waits=0,draws=0,deleted=0;
const g=new Proxy({FRAMEBUFFER_COMPLETE:1,ALREADY_SIGNALED:2,CONDITION_SATISFIED:3,WAIT_FAILED:4,checkFramebufferStatus:()=>1,clientWaitSync:()=>++waits%3?5:2,deleteSync:()=>deleted++},{get:(o,k)=>k in o?o[k]:typeof k==='string'&&k===k.toUpperCase()?0:()=>({})});
const pass=new UncappedPass({gl:g,draw(){draws++;}},{width:1280,height:720});const start=performance.now()+20;const result=await pass.run({measureAt:start,endAt:start+120,signal:new AbortController().signal,scene:()=>null});assert(result.completedScenes>0);assert(result.completedScenes<=draws);assert.equal(result.scenesPerSecond,result.completedScenes/.12);assert(result.scenesPerSecond>60);assert(result.trace.every(x=>x.at<=.12));assert(deleted>0);pass.dispose();
const controller=new AbortController();controller.abort();await assert.rejects(pass.run({measureAt:performance.now(),endAt:performance.now()+50,signal:controller.signal,scene:()=>null}),{name:'AbortError'});
for(const hero of ['goku','vegeta'])for(let form=0;form<roster[hero].forms.length;form++)for(let attack=0;attack<roster[hero].attacks.length;attack++){const frame=fightFrame(8,{hero,form,attack,foeForm:7,intensity:4,tour:false});assert(frame.points.length<=40000);assert([...frame.points].every(Number.isFinite));assert.equal(frame.attack,roster[hero].attacks[attack][0]);}
console.log('PASS: delayed fence completion, >60 simulated throughput, warmup/end boundaries, cancellation, all form/attack combinations. Mock GPU, not hardware validation.');
