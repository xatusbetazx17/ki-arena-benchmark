#!/usr/bin/env python3
"""Run Ki Arena locally on Windows or Linux with Python 3 (standard library only)."""
import argparse
import json
from urllib.parse import urlsplit
from hardware import HardwareMonitor
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import threading
import webbrowser

class GameHandler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map, '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png'}
    def do_GET(self):
        authority = '127.0.0.1:'+str(self.server.server_address[1])
        if self.headers.get('Host') != authority:
            self.send_error(403, 'Open the exact local URL printed by the launcher.'); return
        if urlsplit(self.path).path == '/api/hardware':
            if self.headers.get('Origin') not in (None, 'http://'+authority) or self.headers.get('Sec-Fetch-Site') == 'cross-site':
                self.send_error(403); return
            data = json.dumps(self.server.hardware.snapshot(), allow_nan=False).encode('utf-8')
            self.send_response(200); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(data))); self.end_headers(); self.wfile.write(data); return
        super().do_GET()

    def end_headers(self):
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        self.send_header('Cache-Control', 'no-cache')
        self.send_header('X-Content-Type-Options', 'nosniff')
        super().end_headers()
    def log_message(self, *_args):
        pass

def public_root():
    root = Path(__file__).resolve().parent
    return root / 'dist' if (root / 'dist' / 'index.html').is_file() else root

def make_server(port=0):
    root = public_root()
    required = ['index.html', 'app.js', 'worker.js', 'fight.js', 'forms.js', 'saga.js', 'hardware.js', 'uncapped.js', 'sprite-bounds.js', 'assets/goku-forms.png', 'assets/vegeta-forms.png', 'assets/frieza-forms.png', 'assets/goku.png', 'assets/frieza.png', 'assets/stage.png']
    missing = [name for name in required if not (root / name).is_file()]
    if missing:
        raise FileNotFoundError('Extract the complete game folder. Missing: ' + ', '.join(missing))
    server = ThreadingHTTPServer(('127.0.0.1', port), partial(GameHandler, directory=str(root)))
    server.daemon_threads = True
    server.hardware = HardwareMonitor()
    server.hardware.start()
    return server

def main():
    parser = argparse.ArgumentParser(description='Launch Ki Arena Goku battle benchmark')
    parser.add_argument('--port', type=int, default=0, help='Local port (0 chooses a free port)')
    parser.add_argument('--no-browser', action='store_true', help='Print the URL without opening a browser')
    args = parser.parse_args()
    if not 0 <= args.port <= 65535:
        parser.error('Port must be between 0 and 65535')
    with make_server(args.port) as server:
        url = 'http://127.0.0.1:{}/'.format(server.server_address[1])
        print('\nKi Arena 3.2 — Goku Battle Benchmark\n' + url, flush=True)
        print('Keep this window open while playing. Press Ctrl+C to close the local server.', flush=True)
        if not args.no_browser:
            threading.Timer(0.4, lambda: webbrowser.open(url)).start()
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print('\nKi Arena closed.')
        finally:
            server.hardware.close()

if __name__ == '__main__':
    main()
