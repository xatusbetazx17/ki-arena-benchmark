#!/bin/sh
set -eu
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
    printf '%s\n' 'Python 3 is required for the offline launcher. Install it using your distribution package manager.'
    exit 1
fi
exec python3 ./launcher.py "$@"
