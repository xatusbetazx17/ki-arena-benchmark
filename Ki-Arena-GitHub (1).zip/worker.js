'use strict';
// KI Arena 2.0: deterministic, observable workloads. No network access.
const N=2048;
function cpu(duration,seed){
 const x=new Float64Array(N),y=new Float64Array(N),vx=new Float64Array(N),vy=new Float64Array(N);
 let s=seed>>>0;const rnd=()=>{s=(Math.imul(s,1664525)+1013904223)>>>0;return s/4294967296;};
 for(let i=0;i<N;i++){x[i]=rnd()*2-1;y[i]=rnd()*2-1;vx[i]=(rnd()-.5)*.01;vy[i]=(rnd()-.5)*.01;}
 const start=performance.now();let count=0,now=start;
 do{for(let k=0;k<4;k++){for(let i=0;i<N;i++){const inv=1/Math.sqrt(x[i]*x[i]+y[i]*y[i]+.05);vx[i]=(vx[i]-.0003*x[i]*inv)*.999;vy[i]=(vy[i]-.0003*y[i]*inv)*.999;x[i]+=vx[i];y[i]+=vy[i];}count+=N;}now=performance.now();}while(now-start<duration);
 let checksum=0;for(let i=0;i<N;i++)checksum+=x[i]+y[i]+vx[i]+vy[i];
 return{count,elapsed:now-start,start:performance.timeOrigin+start,end:performance.timeOrigin+now,checksum};
}
let a,b;
function copy(duration){
 if(!a){a=new Uint8Array(32*1024*1024);b=new Uint8Array(a.length);for(let i=0;i<a.length;i+=4096)a[i]=(i/4096)%251;}
 const start=performance.now();let count=0,now=start,checksum=0;
 do{b.set(a);checksum+=b[(count*4096)%b.length];const t=a;a=b;b=t;count++;now=performance.now();}while(now-start<duration);
 return{count:count*a.length,elapsed:now-start,start:performance.timeOrigin+start,end:performance.timeOrigin+now,checksum};
}
self.onmessage=({data:d})=>{if(!['cpu','copy'].includes(d.type)||!Number.isFinite(d.duration)||d.duration<=0||d.duration>2000){self.postMessage({id:d.id,error:'Invalid workload'});return;}const wait=Math.max(0,(d.startAt||0)-(performance.timeOrigin+performance.now()));setTimeout(()=>{try{const result=d.type==='cpu'?cpu(d.duration,d.seed||12345):copy(d.duration);self.postMessage({id:d.id,...result});}catch(e){self.postMessage({id:d.id,error:e.message});}},wait);};

// Combined battle workload: run beside real rendering, warm up, then count work
// in the shared absolute-time measurement window. Yield between bounded chunks.
function battle(d){
 const x=new Float64Array(N),y=new Float64Array(N),vx=new Float64Array(N),vy=new Float64Array(N);
 let seed=12345;const rnd=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 for(let i=0;i<N;i++){x[i]=rnd()*2-1;y[i]=rnd()*2-1;vx[i]=(rnd()-.5)*.01;vy[i]=(rnd()-.5)*.01;}
 let count=0,measuredStart=null,end=null,lastProgress=0,steps=0;
 const reset=()=>{seed=12345;for(let i=0;i<N;i++){x[i]=rnd()*2-1;y[i]=rnd()*2-1;vx[i]=(rnd()-.5)*.01;vy[i]=(rnd()-.5)*.01;}};
 const absolute=()=>performance.timeOrigin+performance.now();
 function chunk(){
  try{
   const chunkStart=performance.now();
   do{
    const before=absolute();if(before>=d.endAt){finish();return;}
    if(before>=d.measureAt&&measuredStart===null)measuredStart=before;
    for(let i=0;i<N;i++){const inv=1/Math.sqrt(x[i]*x[i]+y[i]*y[i]+.05);vx[i]=(vx[i]-.0003*x[i]*inv)*.999;vy[i]=(vy[i]-.0003*y[i]*inv)*.999;x[i]+=vx[i];y[i]+=vy[i];}
    if(++steps%4096===0)reset();
    if(measuredStart!==null){count+=N;end=absolute();}
   }while(performance.now()-chunkStart<24);
   const now=absolute();if(now-lastProgress>=500){self.postMessage({id:d.id,progress:true,count,start:measuredStart,end});lastProgress=now;}
   setTimeout(chunk,0);
  }catch(e){self.postMessage({id:d.id,error:e.message});}
 }
 function finish(){let checksum=0;for(let i=0;i<N;i++)checksum+=x[i]+y[i]+vx[i]+vy[i];self.postMessage({id:d.id,count,start:measuredStart,end,elapsed:end-measuredStart,checksum});}
 chunk();
}
const originalHandler=self.onmessage;
self.onmessage=event=>{const d=event.data;if(d.type!=='battle'){originalHandler(event);return;}const now=performance.timeOrigin+performance.now();if(!Number.isFinite(d.measureAt)||!Number.isFinite(d.endAt)||d.endAt<=d.measureAt||d.endAt-now>185000||d.endAt<now){self.postMessage({id:d.id,error:'Invalid battle timing window'});return;}battle(d);};
