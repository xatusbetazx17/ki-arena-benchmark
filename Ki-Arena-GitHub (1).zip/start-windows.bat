@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 goto run_py
where python >nul 2>&1
if not errorlevel 1 goto run_python
echo Python 3 is required for the offline launcher.
echo Install Python 3 from https://www.python.org/downloads/windows/
echo Or use the hosted game in a WebGL 2 browser.
pause
exit /b 1
:run_py
py -3 "%~dp0launcher.py" %*
goto finished
:run_python
python "%~dp0launcher.py" %*
:finished
if errorlevel 1 pause
